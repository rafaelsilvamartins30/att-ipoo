public class App { // classe principal
    public static void main(String[] args) { // metodo principal
        Prova prova = new Prova(); // cria um objeto da classe prova
        prova.aplicar(); // aplica a prova usando metodo
    }
}
