public class App {
    public static void main(String[] args)  {
        Horario h1 = new Horario(10,15,43);
        Horario h2 = new Horario(3690);
        Horario h3 = new Horario(3521);
        Horario h4 = new Horario(59);

        h1.exibir();
        h2.exibir();
        h3.exibir();
        h4.exibir();
    }
}
