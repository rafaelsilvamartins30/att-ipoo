import java.util.Scanner;

public class App { // classe principal
    public static void main(String[] args) { // metodo principal
        Scanner entrada = new Scanner(System.in);
        Prova prova = new Prova(); // cria um objeto da classe prova
        prova.aplicar(); // aplica a prova usando metodo
        int aux;
        System.out.println("você quer ver sua tabela de resultados? se sim digite 1 se não outro valor");
        aux = entrada.nextInt();
        if (aux == 1) {
            prova.gerarCorrecao();
        } else {
            System.out.println("programa encerrado");
        }
    }
}
