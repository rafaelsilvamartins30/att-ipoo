import java.util.Scanner; // para ler entradas

public class Prova { // classe prova
    private Questao[] questao; // atributo privado para so a classe acessar que apresenta uma questao da classe Questao 
    private Correcao[] correcao;

    public Prova() { // construtor publico para poder ser acessado por qualquer um, quando criado um objeto da classe prova uma questao é gerada 
        questao = new Questao[5];
        for(int i = 0; i < 5; i++){
            questao[i] = new Questao();
        }
    }

    public void aplicar() { // metodo publico para poder ser acessado por qualquer um que aplica a prova
        Scanner entrada = new Scanner(System.in); // cria um objeto da classe Scanner
        correcao = new Correcao[5];
        for(int i = 0; i < 5; i++){        
            System.out.println("Questão " + questao[i].consultarIdQuestao());
            System.out.println(questao[i].consultarEnunciado()); // mostra a pergunta 
            System.out.print("Sua resposta: "); // pede a resposta
            int resposta = entrada.nextInt(); // recebe a resposta
            int contador = 0;
            if (questao[i].corrigir(resposta)) { //condicional para correção
                System.out.println("Você tentou 1 vez e acertou a questão."); // se acertar de primeira
                contador = 1;
            } else {
                System.out.println("Você ganhou mais uma chance! Digite outra resposta para a questão."); // se errar a primeira tenta denovo
                contador = 2;
                System.out.print("Sua nova resposta: "); // pede a nova resposta
                resposta = entrada.nextInt(); // recebe a nova resposta

                if (questao[i].corrigir(resposta)) { // condicional se acertar ou errar a segunda vez
                    System.out.println("Você tentou 2 vezes e acertou a questão.");
                } else {
                    System.out.println("Você tentou 2 vezes e errou a questão.");
                }
            }
            correcao[i] = new Correcao(questao[i].consultarIdQuestao(), questao[i].corrigir(resposta), contador);
        }
    }

    public void gerarCorrecao() {
        if (correcao != null) {
            System.out.println("Questão - Acertou - Num de Tentativas");
            for (int i = 0; i < 5; i++) {
                System.out.printf("   %d    -   %s   -      %d%n", correcao[i].getidQues(), correcao[i].getresultado() ? "Sim" : "Não", correcao[i].getnumTentativas());
            }
        }
    }
    
}
