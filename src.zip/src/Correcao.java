public class Correcao {
    private int idQues;
    private boolean resultado;
    private int numTentativas;
    
    public Correcao(int idQues, boolean resultado, int numTentativas){
        this.idQues = idQues;
        this.resultado = resultado;
        this.numTentativas = numTentativas;
    }

    public int getidQues(){
        return idQues;
    }

    public boolean getresultado(){
        return resultado;
    }

    public int getnumTentativas(){
        return numTentativas;
    }

    
}